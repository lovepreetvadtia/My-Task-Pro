import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema updated for employee management
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["admin", "employee"] }).notNull().default("employee"),
  department: text("department"),
  position: text("position"),
  joinDate: timestamp("join_date").defaultNow(),
});

// Project schema for project-based task organization
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdById: integer("created_by_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category", { 
    enum: ["development", "design", "testing", "documentation", "maintenance"] 
  }).notNull().default("development"), 
  status: text("status", { 
    enum: ["todo", "in_progress", "completed"] 
  }).notNull().default("todo"),
  priority: text("priority", { 
    enum: ["low", "medium", "high"] 
  }).notNull().default("medium"),
  assigneeId: integer("assignee_id").references(() => users.id), 
  projectId: integer("project_id").references(() => projects.id), 
  createdById: integer("created_by_id").references(() => users.id).notNull(),
  timeSpent: integer("time_spent").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  token: text("token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  status: text("status", { enum: ["absent", "half_day", "full_day"] }).notNull(),
  markedById: integer("marked_by_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  role: true,
  department: true,
  position: true,
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
});

export const insertTaskSchema = createInsertSchema(tasks)
  .pick({
    title: true,
    description: true,
    category: true,
    status: true,
    priority: true,
    assigneeId: true,
    projectId: true,
  })
  .extend({
    assigneeId: z.number({ required_error: "Assignee is required" }),
    projectId: z.number({ required_error: "Project is required" }),
    category: z.enum(["development", "design", "testing", "documentation", "maintenance"], {
      required_error: "Category is required"
    }),
  });

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  title: true,
  message: true,
  userId: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).pick({
  userId: true,
  date: true,
  status: true,
});

export const resetPasswordSchema = z.object({
  email: z.string().email(),
  token: z.string().optional(),
  newPassword: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type User = typeof users.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Attendance = typeof attendance.$inferSelect;
export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;