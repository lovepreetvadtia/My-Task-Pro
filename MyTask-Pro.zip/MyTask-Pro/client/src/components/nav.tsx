import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, CheckSquare, LogOut, Sun, Moon, UserCheck, FolderKanban, Users } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { NotificationDropdown } from "./notification-dropdown";

export function Nav() {
  const { user, logoutMutation } = useAuth();
  const { theme, setTheme } = useTheme();

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 items-center px-4">
        <div className="flex items-center space-x-4 lg:space-x-6">
          <Link href="/">
            <Button variant="ghost" className="flex items-center space-x-2">
              <LayoutDashboard className="h-4 w-4" />
              <span>Dashboard</span>
            </Button>
          </Link>
          <Link href="/projects">
            <Button variant="ghost" className="flex items-center space-x-2">
              <FolderKanban className="h-4 w-4" />
              <span>Projects</span>
            </Button>
          </Link>
          <Link href="/tasks">
            <Button variant="ghost" className="flex items-center space-x-2">
              <CheckSquare className="h-4 w-4" />
              <span>Tasks</span>
            </Button>
          </Link>
          {user?.role === "admin" && (
            <>
              <Link href="/attendance">
                <Button variant="ghost" className="flex items-center space-x-2">
                  <UserCheck className="h-4 w-4" />
                  <span>Attendance</span>
                </Button>
              </Link>
              <Link href="/employees">
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span>Team</span>
                </Button>
              </Link>
            </>
          )}
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <NotificationDropdown />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
          <span className="text-sm text-muted-foreground">
            {user?.username} ({user?.role})
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </nav>
  );
}