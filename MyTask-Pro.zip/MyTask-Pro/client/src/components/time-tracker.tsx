import { useState, useEffect } from "react";
import { Play, Pause, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function TimeTracker({ taskId, currentTime = 0, onUpdate }: { taskId: number; currentTime?: number; onUpdate: () => void }) {
  const [time, setTime] = useState(currentTime);
  const [isRunning, setIsRunning] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    let interval: number;
    if (isRunning) {
      interval = window.setInterval(() => {
        setTime((t) => t + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleSave = async () => {
    try {
      await apiRequest("POST", `/api/tasks/${taskId}/time`, { timeSpent: time });
      toast({
        title: "Time saved successfully",
        description: `Recorded ${formatTime(time)} for this task.`,
      });
      onUpdate();
    } catch (error) {
      toast({
        title: "Failed to save time",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <div className="font-mono">{formatTime(time)}</div>
      <Button
        size="icon"
        variant="outline"
        onClick={() => setIsRunning(!isRunning)}
      >
        {isRunning ? (
          <Pause className="h-4 w-4" />
        ) : (
          <Play className="h-4 w-4" />
        )}
      </Button>
      <Button
        size="icon"
        variant="outline"
        onClick={handleSave}
        disabled={time === currentTime}
      >
        <Save className="h-4 w-4" />
      </Button>
    </div>
  );
}
