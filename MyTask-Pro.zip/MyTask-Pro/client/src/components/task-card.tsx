import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Task } from "@shared/schema";
import { TimeTracker } from "./time-tracker";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreVertical, Trash2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

const priorityColors = {
  low: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  high: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

const statusColors = {
  todo: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
  in_progress: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  completed: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
};

export function TaskCard({ task, users, projects }: { 
  task: Task; 
  users?: { id: number; username: string }[];
  projects?: { id: number; name: string }[];
}) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    try {
      setIsDeleting(true);
      await apiRequest("DELETE", `/api/tasks/${task.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task deleted",
        description: "The task has been successfully deleted.",
      });

      // Notify admin about task deletion
      if (user?.role === "admin") {
        toast({
          title: "Admin Notification",
          description: `Task "${task.title}" was deleted`,
          variant: "default",
        });
      }
    } catch (error) {
      toast({
        title: "Failed to delete task",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const handleStatusChange = async (status: string) => {
    try {
      await apiRequest("PATCH", `/api/tasks/${task.id}`, { status });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });

      // Notify admin about task completion
      if (status === "completed" && user?.role === "admin") {
        toast({
          title: "Admin Notification",
          description: `Task "${task.title}" was marked as completed`,
          variant: "default",
        });
      }
    } catch (error) {
      toast({
        title: "Failed to update status",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  };

  const project = projects?.find(p => p.id === task.projectId);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{task.title}</CardTitle>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              disabled={isDeleting}
              onClick={handleDelete}
              className="text-red-600"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("todo")}>
              Mark as Todo
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("in_progress")}>
              Mark as In Progress
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("completed")}>
              Mark as Completed
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-2">
          <div className="flex flex-wrap gap-2">
            <Badge
              variant="secondary"
              className={priorityColors[task.priority as keyof typeof priorityColors]}
            >
              {task.priority}
            </Badge>
            <Badge
              variant="secondary"
              className={statusColors[task.status as keyof typeof statusColors]}
            >
              {task.status}
            </Badge>
            {project && (
              <Link href={`/projects/${project.id}`}>
                <Badge
                  variant="outline"
                  className="cursor-pointer hover:bg-primary/10"
                >
                  {project.name}
                </Badge>
              </Link>
            )}
          </div>

          {task.description && (
            <p className="text-sm text-muted-foreground">{task.description}</p>
          )}

          {users && task.assigneeId && (
            <p className="text-sm text-muted-foreground">
              Assigned to: {users.find(u => u.id === task.assigneeId)?.username}
            </p>
          )}

          <TimeTracker
            taskId={task.id}
            currentTime={task.timeSpent || 0}
            onUpdate={() => queryClient.invalidateQueries({ queryKey: ["/api/tasks"] })}
          />
        </div>
      </CardContent>
    </Card>
  );
}