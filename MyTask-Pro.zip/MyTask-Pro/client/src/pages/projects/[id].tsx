import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Nav } from "@/components/nav";
import { Project, InsertTask, Task } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Plus, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { TaskCard } from "@/components/task-card";
import { useAuth } from "@/hooks/use-auth";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTaskSchema } from "@shared/schema";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

function ProjectDetailsPage() {
  const [, params] = useRoute("/projects/:id");
  const projectId = Number(params?.id);
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  const { data: projectTasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/projects", projectId, "tasks"],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/tasks`);
      return res.json();
    },
  });

  const { data: users } = useQuery<{ id: number; username: string }[]>({
    queryKey: ["/api/users"],
    enabled: user?.role === "admin",
  });

  if (projectLoading || tasksLoading) {
    return (
      <div className="min-h-screen">
        <Nav />
        <div className="flex items-center justify-center min-h-[calc(100vh-3.5rem)]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen">
        <Nav />
        <div className="container mx-auto p-4">
          <h1 className="text-3xl font-bold mb-8">Project not found</h1>
        </div>
      </div>
    );
  }

  const groupedTasks = {
    todo: projectTasks?.filter(task => task.status === "todo") || [],
    in_progress: projectTasks?.filter(task => task.status === "in_progress") || [],
    completed: projectTasks?.filter(task => task.status === "completed") || [],
  };

  return (
    <div className="min-h-screen">
      <Nav />
      <main className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">{project.name}</h1>
            {project.description && (
              <p className="text-muted-foreground mt-2">{project.description}</p>
            )}
          </div>
          {user?.role === "admin" && <AddTaskDialog projectId={projectId} />}
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <h2 className="font-semibold mb-4">To Do</h2>
            <div className="space-y-4">
              {groupedTasks.todo.map(task => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  users={users}
                  projects={[project]}
                />
              ))}
            </div>
          </div>

          <div>
            <h2 className="font-semibold mb-4">In Progress</h2>
            <div className="space-y-4">
              {groupedTasks.in_progress.map(task => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  users={users}
                  projects={[project]}
                />
              ))}
            </div>
          </div>

          <div>
            <h2 className="font-semibold mb-4">Completed</h2>
            <div className="space-y-4">
              {groupedTasks.completed.map(task => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  users={users}
                  projects={[project]}
                />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function AddTaskDialog({ projectId }: { projectId: number }) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const { data: users } = useQuery<{ id: number; username: string }[]>({
    queryKey: ["/api/users"],
  });

  const form = useForm<InsertTask>({
    resolver: zodResolver(insertTaskSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "development",
      status: "todo",
      priority: "medium",
      assigneeId: undefined,
      projectId,
    },
  });

  const addTaskMutation = useMutation({
    mutationFn: async (data: InsertTask) => {
      const res = await apiRequest("POST", "/api/tasks", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "tasks"] });
      setOpen(false);
      toast({
        title: "Task created",
        description: "New task has been created successfully.",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Task
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Task</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((data) => addTaskMutation.mutate(data))}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="development">Development</SelectItem>
                      <SelectItem value="design">Design</SelectItem>
                      <SelectItem value="testing">Testing</SelectItem>
                      <SelectItem value="documentation">Documentation</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="priority"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Priority</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="assigneeId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assign To</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(Number(value))}
                    value={field.value?.toString()}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select assignee" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {users?.map((user) => (
                        <SelectItem key={user.id} value={user.id.toString()}>
                          {user.username}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full"
              disabled={addTaskMutation.isPending}
            >
              {addTaskMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Create Task
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export default ProjectDetailsPage;