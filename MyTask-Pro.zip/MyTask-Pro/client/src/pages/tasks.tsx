import { useQuery } from "@tanstack/react-query";
import { Nav } from "@/components/nav";
import { Task } from "@shared/schema";
import { TaskCard } from "@/components/task-card";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function Tasks() {
  const { user } = useAuth();
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: users } = useQuery<{ id: number; username: string }[]>({
    queryKey: ["/api/users"],
  });

  const { data: projects } = useQuery<{ id: number; name: string }[]>({
    queryKey: ["/api/projects"],
  });

  if (tasksLoading) {
    return (
      <div className="min-h-screen">
        <Nav />
        <div className="flex items-center justify-center min-h-[calc(100vh-3.5rem)]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  // Filter tasks based on user role
  const filteredTasks = tasks?.filter(task => {
    if (user?.role === "admin") {
      return true; // Admins can see all tasks
    }
    return task.assigneeId === user?.id; // Employees only see their assigned tasks
  }) || [];

  const groupedTasks = {
    todo: filteredTasks.filter((t) => t.status === "todo"),
    in_progress: filteredTasks.filter((t) => t.status === "in_progress"),
    completed: filteredTasks.filter((t) => t.status === "completed"),
  };

  return (
    <div className="min-h-screen">
      <Nav />
      <main className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">
            {user?.role === "admin" ? "All Tasks" : "My Tasks"}
          </h1>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div>
            <h2 className="font-semibold mb-4">To Do</h2>
            <div className="space-y-4">
              {groupedTasks.todo.map((task) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  users={users}
                  projects={projects} 
                />
              ))}
            </div>
          </div>

          <div>
            <h2 className="font-semibold mb-4">In Progress</h2>
            <div className="space-y-4">
              {groupedTasks.in_progress.map((task) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  users={users}
                  projects={projects}
                />
              ))}
            </div>
          </div>

          <div>
            <h2 className="font-semibold mb-4">Completed</h2>
            <div className="space-y-4">
              {groupedTasks.completed.map((task) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  users={users}
                  projects={projects}
                />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}