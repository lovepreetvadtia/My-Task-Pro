import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertTaskSchema, insertNotificationSchema, insertAttendanceSchema, resetPasswordSchema, insertProjectSchema } from "@shared/schema";
import { randomBytes } from "crypto";
import { sendPasswordResetEmail, sendWelcomeEmail } from "./email";

function requireAuth(req: Request, res: Response, next: Function) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function requireAdmin(req: Request, res: Response, next: Function) {
  if (!req.isAuthenticated() || req.user.role !== "admin") {
    return res.status(403).json({ message: "Forbidden" });
  }
  next();
}

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Password Reset
  app.post("/api/forgot-password", async (req, res) => {
    const result = resetPasswordSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const user = await storage.getUserByEmail(result.data.email);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const token = randomBytes(32).toString("hex");
    await storage.createPasswordResetToken(user.id, token);
    await sendPasswordResetEmail(user.email, token);

    res.sendStatus(200);
  });

  app.post("/api/reset-password", async (req, res) => {
    const result = resetPasswordSchema.safeParse(req.body);
    if (!result.success || !result.data.token || !result.data.newPassword) {
      return res.status(400).json({ message: "Invalid request" });
    }

    const resetToken = await storage.getValidPasswordResetToken(result.data.token);
    if (!resetToken) {
      return res.status(400).json({ message: "Invalid or expired token" });
    }

    await storage.updateUserPassword(resetToken.userId, result.data.newPassword);
    await storage.markPasswordResetTokenAsUsed(result.data.token);

    res.sendStatus(200);
  });

  // Send welcome email after registration
  app.post("/api/register", async (req, res, next) => {
    try {
      const user = await storage.createUser(req.body);
      await sendWelcomeEmail(user.email, user.username);
      res.status(201).json(user);
    } catch (error) {
      next(error);
    }
  });

  // Tasks
  app.get("/api/tasks", requireAuth, async (req, res) => {
    // If admin, return all tasks, if employee return only their tasks
    const tasks = await storage.getTasks();
    if (req.user!.role === "admin") {
      res.json(tasks);
    } else {
      const userTasks = tasks.filter(task => task.assigneeId === req.user!.id);
      res.json(userTasks);
    }
  });

  app.post("/api/tasks", requireAdmin, async (req, res) => {
    const result = insertTaskSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    // Validate project exists
    const project = await storage.getProject(result.data.projectId);
    if (!project) {
      return res.status(400).json({ message: "Project not found" });
    }

    // Verify employee exists
    const employee = await storage.getUser(result.data.assigneeId);
    if (!employee) {
      return res.status(400).json({ message: "Invalid assignee" });
    }

    const task = await storage.createTask({
      ...result.data,
      createdById: req.user!.id,
    });

    // Create notification for the assigned employee
    await storage.createNotification({
      userId: result.data.assigneeId,
      title: "New Task Assignment",
      message: `You have been assigned a new ${task.priority} priority task: ${task.title}`,
    });

    res.status(201).json(task);
  });

  // Get tasks for a specific project
  app.get("/api/projects/:id/tasks", requireAuth, async (req, res) => {
    const projectId = Number(req.params.id);

    // Verify project exists
    const project = await storage.getProject(projectId);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const tasks = await storage.getTasksByProject(projectId);
    res.json(tasks);
  });

  app.patch("/api/tasks/:id", requireAuth, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Only allow admins to modify any task, employees can only modify their assigned tasks
    if (req.user!.role !== "admin" && task.assigneeId !== req.user!.id) {
      return res.status(403).json({ message: "Forbidden" });
    }

    // Employees can only update status and timeSpent
    if (req.user!.role !== "admin") {
      const allowedUpdates = ["status", "timeSpent"];
      const attemptedUpdates = Object.keys(req.body);
      const hasInvalidUpdates = attemptedUpdates.some(update => !allowedUpdates.includes(update));
      if (hasInvalidUpdates) {
        return res.status(403).json({ 
          message: "Employees can only update task status and time spent" 
        });
      }
    }

    const updatedTask = await storage.updateTask(Number(req.params.id), req.body);

    // Create notification for task completion
    if (req.body.status === "completed") {
      const admins = (await storage.getAllUsers()).filter(u => u.role === "admin");
      for (const admin of admins) {
        await storage.createNotification({
          userId: admin.id,
          title: "Task Completed",
          message: `${req.user!.username} completed the task: ${task.title}`,
        });
      }
    }

    res.json(updatedTask);
  });

  // Only admins can delete tasks
  app.delete("/api/tasks/:id", requireAdmin, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    await storage.deleteTask(Number(req.params.id));

    // Notify the assigned employee about task deletion
    if (task.assigneeId) {
      await storage.createNotification({
        userId: task.assigneeId,
        title: "Task Deleted",
        message: `Task "${task.title}" has been deleted by admin`,
      });
    }

    res.sendStatus(204);
  });

  // Time tracking
  app.post("/api/tasks/:id/time", requireAuth, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    const timeSpent = Number(req.body.timeSpent);
    if (isNaN(timeSpent)) {
      return res.status(400).json({ message: "Invalid time spent value" });
    }

    const updatedTask = await storage.updateTaskTime(Number(req.params.id), timeSpent);
    res.json(updatedTask);
  });

  // Users (admin only)
  app.get("/api/users", requireAdmin, async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  // Notifications
  app.get("/api/notifications", requireAuth, async (req, res) => {
    const notifications = await storage.getNotifications(req.user!.id);
    res.json(notifications);
  });

  app.post("/api/notifications", requireAuth, async (req, res) => {
    const result = insertNotificationSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const notification = await storage.createNotification(result.data);
    res.status(201).json(notification);
  });

  app.post("/api/notifications/:id/read", requireAuth, async (req, res) => {
    await storage.markNotificationAsRead(Number(req.params.id));
    res.sendStatus(200);
  });

  // Attendance
  app.get("/api/attendance", requireAdmin, async (req, res) => {
    const attendance = await storage.getAttendance(Number(req.query.userId));
    res.json(attendance);
  });

  app.post("/api/attendance", requireAdmin, async (req, res) => {
    const result = insertAttendanceSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const attendance = await storage.createAttendance({
      ...result.data,
      markedById: req.user!.id,
    });

    // Create notification for the employee
    await storage.createNotification({
      userId: result.data.userId,
      title: "Attendance Marked",
      message: `Your attendance for ${new Date(result.data.date).toLocaleDateString()} has been marked as ${result.data.status}`,
    });

    res.status(201).json(attendance);
  });

  // Projects (Admin only)
  app.get("/api/projects", requireAuth, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.post("/api/projects", requireAdmin, async (req, res) => {
    const result = insertProjectSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const project = await storage.createProject({
      ...result.data,
      createdById: req.user!.id,
    });

    // Notify all employees about new project
    const employees = (await storage.getAllUsers()).filter(u => u.role === "employee");
    for (const employee of employees) {
      await storage.createNotification({
        userId: employee.id,
        title: "New Project Created",
        message: `A new project "${project.name}" has been created`,
      });
    }

    res.status(201).json(project);
  });

  app.get("/api/projects/:id", requireAuth, async (req, res) => {
    const project = await storage.getProject(Number(req.params.id));
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    res.json(project);
  });

  // Get employees list (for admin task assignment)
  app.get("/api/employees", requireAdmin, async (req, res) => {
    const users = await storage.getAllUsers();
    const employees = users.filter(user => user.role === "employee");
    res.json(employees);
  });


  const httpServer = createServer(app);
  return httpServer;
}