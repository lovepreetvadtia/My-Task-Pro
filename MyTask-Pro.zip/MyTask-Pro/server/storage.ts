import { users, tasks, notifications, attendance, passwordResetTokens, projects } from "@shared/schema";
import type { InsertUser, User, InsertTask, Task, InsertNotification, Notification, InsertAttendance, Attendance, PasswordResetToken, InsertProject, Project } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  createTask(task: InsertTask & { createdById: number }): Promise<Task>;
  getTask(id: number): Promise<Task | undefined>;
  updateTask(id: number, task: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<void>;
  getTasks(): Promise<Task[]>;
  updateTaskTime(id: number, timeSpent: number): Promise<Task | undefined>;

  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotifications(userId: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<void>;

  createAttendance(attendance: InsertAttendance & { markedById: number }): Promise<Attendance>;
  getAttendance(userId: number): Promise<Attendance[]>;

  createPasswordResetToken(userId: number, token: string): Promise<PasswordResetToken>;
  getValidPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenAsUsed(token: string): Promise<void>;
  updateUserPassword(userId: number, newPassword: string): Promise<void>;

  sessionStore: session.Store;
  createProject(project: InsertProject & { createdById: number }): Promise<Project>;
  getProject(id: number): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  getTasksByProject(projectId: number): Promise<Task[]>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      joinDate: new Date(),
    }).returning();
    return user;
  }

  async createTask(task: InsertTask & { createdById: number }): Promise<Task> {
    const [newTask] = await db.insert(tasks).values({
      ...task,
      description: task.description ?? null,
      timeSpent: 0,
      createdAt: new Date(),
      status: task.status || "todo",
      priority: task.priority || "medium",
      projectId: task.projectId ?? null,
      assigneeId: task.assigneeId ?? null,
    }).returning();
    return newTask;
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined> {
    const [task] = await db.update(tasks)
      .set(updates)
      .where(eq(tasks.id, id))
      .returning();
    return task;
  }

  async deleteTask(id: number): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  async updateTaskTime(id: number, timeSpent: number): Promise<Task | undefined> {
    return this.updateTask(id, { timeSpent });
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values({
      ...notification,
      read: false,
      createdAt: new Date(),
    }).returning();
    return newNotification;
  }

  async getNotifications(userId: number): Promise<Notification[]> {
    return await db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id));
  }

  async createAttendance(attendance: InsertAttendance & { markedById: number }): Promise<Attendance> {
    const [newAttendance] = await db.insert(attendance)
      .values({
        userId: attendance.userId,
        date: attendance.date,
        status: attendance.status,
        markedById: attendance.markedById,
        createdAt: new Date(),
      })
      .returning();
    return newAttendance as Attendance;
  }

  async getAttendance(userId: number): Promise<Attendance[]> {
    return await db.select()
      .from(attendance)
      .where(eq(attendance.userId, userId))
      .orderBy(desc(attendance.date));
  }

  async createPasswordResetToken(userId: number, token: string): Promise<PasswordResetToken> {
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 1);

    const [resetToken] = await db.insert(passwordResetTokens).values({
      userId,
      token,
      expiresAt,
      used: false,
    }).returning();
    return resetToken;
  }

  async getValidPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const now = new Date();
    const [resetToken] = await db.select()
      .from(passwordResetTokens)
      .where(
        and(
          eq(passwordResetTokens.token, token),
          eq(passwordResetTokens.used, false)
        )
      );

    return resetToken && resetToken.expiresAt > now ? resetToken : undefined;
  }

  async markPasswordResetTokenAsUsed(token: string): Promise<void> {
    await db.update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.token, token));
  }

  async updateUserPassword(userId: number, newPassword: string): Promise<void> {
    await db.update(users)
      .set({ password: newPassword })
      .where(eq(users.id, userId));
  }

  async createProject(project: InsertProject & { createdById: number }): Promise<Project> {
    const [newProject] = await db.insert(projects).values({
      ...project,
      description: project.description ?? null,
      createdAt: new Date(),
    }).returning();
    return newProject;
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async getTasksByProject(projectId: number): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(eq(tasks.projectId, projectId));
  }
}

export const storage = new DatabaseStorage();